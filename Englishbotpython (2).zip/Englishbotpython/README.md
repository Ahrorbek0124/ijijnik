## Telegram English Bot (Python)

### Important
- **Do not hardcode your bot token** in code.
- If you shared your token publicly, **revoke it in BotFather** and generate a new one.

### Run from the project folder

```powershell
cd "C:\Users\abdus\OneDrive\Pictures\loyihalar\English bot python"
python -m pip install -r "TgBotPy\requirements.txt"
$env:TELEGRAM_BOT_TOKEN="PASTE_YOUR_NEW_TOKEN_HERE"
python -m TgBotPy
```

### Install once, then run anywhere

```powershell
cd "C:\Users\abdus\OneDrive\Pictures\loyihalar\English bot python"
python -m pip install -e .
```

Now you can run the bot from **any folder**:

```powershell
$env:TELEGRAM_BOT_TOKEN="PASTE_YOUR_NEW_TOKEN_HERE"
english-bot
```

Or pass the token directly:

```powershell
english-bot --token "PASTE_YOUR_NEW_TOKEN_HERE"
```

