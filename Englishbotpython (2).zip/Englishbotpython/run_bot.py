from __future__ import annotations

import os
import sys
from pathlib import Path


def _ensure_project_on_syspath() -> None:
    project_root = Path(__file__).resolve().parent
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))


def main() -> None:
    _ensure_project_on_syspath()
    from TgBotPy.main import main as pkg_main  # noqa: PLC0415

    pkg_main()


if __name__ == "__main__":
    if os.name == "nt":
        # Improves Ctrl+C behavior on Windows terminals in some cases
        os.system("")  # nosec B605,B607
    main()

